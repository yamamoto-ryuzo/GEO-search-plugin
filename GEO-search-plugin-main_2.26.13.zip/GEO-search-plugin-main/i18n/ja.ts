<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>地図検索</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>検索ダイアログ</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>地番検索</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>所有者検索</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>完全一致</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>あいまい検索</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>部分一致</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>前方一致</translation>
    </message>
</context>
</TS>
