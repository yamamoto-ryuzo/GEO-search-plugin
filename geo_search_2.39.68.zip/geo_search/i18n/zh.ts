<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>地理搜索</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>搜索对话框</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>地号搜索</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>所有者搜索</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>精确匹配</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>模糊搜索</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>部分匹配</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>前向匹配</translation>
    </message>
</context>
</TS>
