<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi_IN">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>जियो खोज</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>खोज संवाद</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>लॉट नंबर खोज</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>मालिक खोज</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>सटीक मिलान</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>फजी खोज</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>आंशिक मिलान</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>फॉरवर्ड मिलान</translation>
    </message>
</context>
</TS>
