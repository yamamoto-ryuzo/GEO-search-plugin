<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>Recherche Géo</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>Dialogue de recherche</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>Recherche par numéro de lot</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>Recherche de propriétaire</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>Correspondance exacte</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>Recherche approximative</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>Correspondance partielle</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>Correspondance avant</translation>
    </message>
</context>
</TS>
