<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>Geo-Suche</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>Suchdialog</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>Flurstücksuche</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>Eigentümersuche</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>Exakte Übereinstimmung</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>Ungefähre Suche</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>Teilweise Übereinstimmung</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>Vorwärtsübereinstimmung</translation>
    </message>
</context>
</TS>
