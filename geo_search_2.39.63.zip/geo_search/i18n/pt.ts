<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_PT">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>Busca Geo</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>Diálogo de busca</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>Busca por número de lote</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>Busca de proprietário</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>Correspondência exata</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>Busca aproximada</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>Correspondência parcial</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>Correspondência para frente</translation>
    </message>
</context>
</TS>
