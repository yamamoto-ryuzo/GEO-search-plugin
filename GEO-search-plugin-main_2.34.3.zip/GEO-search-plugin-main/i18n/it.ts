<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it_IT">
<context>
    <name>plugin</name>
    <message>
        <source>Geo Search</source>
        <translation>Ricerca Geo</translation>
    </message>
    <message>
        <source>Search Dialog</source>
        <translation>Dialogo di ricerca</translation>
    </message>
    <message>
        <source>Lot Number Search</source>
        <translation>Ricerca per numero di lotto</translation>
    </message>
    <message>
        <source>Owner Search</source>
        <translation>Ricerca proprietario</translation>
    </message>
    <message>
        <source>Exact Match</source>
        <translation>Corrispondenza esatta</translation>
    </message>
    <message>
        <source>Fuzzy Search</source>
        <translation>Ricerca approssimativa</translation>
    </message>
    <message>
        <source>Partial Match</source>
        <translation>Corrispondenza parziale</translation>
    </message>
    <message>
        <source>Forward Match</source>
        <translation>Corrispondenza in avanti</translation>
    </message>
</context>
</TS>
